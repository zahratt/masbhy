//
//  ViewController.swift
//  masbhy
//
//  Created by mac on 12/05/1443 AH.
//

import UIKit

class ViewController: UIViewController {
    
    
    var count0:Int = 0
    var count1:Int = 0
    var count2:Int = 0
    var count3:Int = 0
    
    
    @IBOutlet var a0: UILabel!
    
    @IBOutlet var a1: UILabel!
    
    @IBOutlet var a2: UILabel!
    
    @IBOutlet var a3: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func s0(_ sender: UIButton) {
        count0 = count0 + 1
        a0.text = " \(count0)"    }
    
    @IBAction func s1(_ sender: Any) {
        count1 = count1 + 1
        a1.text = " \(count1)"    }
    @IBAction func s2(_ sender: Any) {
        count2 = count2 + 1
        a2.text = " \(count2)"    }
    @IBAction func s3(_ sender: Any) {
        count3 = count3 + 1
        a3.text = " \(count3)"    }
    
    @IBAction func r0(_ sender: Any) {count0 = 0
        a0.text = " \(count0)"
    }
    @IBAction func r1(_ sender: Any) {
        count1 = 0
        a1.text = " \(count1)"    }
    @IBAction func r2(_ sender: Any) {
        count2 = 0
        a2.text = " \(count2)"    }
    @IBAction func r3(_ sender: Any) {
        count3 = 0
        a3.text = " \(count3)"    }
    
    @IBAction func s4(_ sender: Any) {
        count0 = 0
        a0.text = " \(count0)"
        count1 = 0
        a1.text = " \(count1)"
        count2 = 0
        a2.text = " \(count2)"
        count3 = 0
        a3.text = " \(count3)"    }
}

